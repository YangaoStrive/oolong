package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Lushr extends NoArgsSequence
{
    public Lushr()
    {
        super(0, -1, opc_lushr);
    }
}
