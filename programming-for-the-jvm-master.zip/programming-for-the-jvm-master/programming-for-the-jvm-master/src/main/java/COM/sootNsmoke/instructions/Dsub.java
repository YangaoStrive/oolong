package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Dsub extends NoArgsSequence
{
    public Dsub()
    {
        super(0, -2, opc_dsub);
    }
}
