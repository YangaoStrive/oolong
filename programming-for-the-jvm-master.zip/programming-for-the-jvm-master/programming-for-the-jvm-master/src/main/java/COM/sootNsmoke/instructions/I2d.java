package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class I2d extends NoArgsSequence
{
    public I2d()
    {
        super(0, 1, opc_i2d);
    }
}
