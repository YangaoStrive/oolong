package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class D2f extends NoArgsSequence
{
    public D2f()
    {
        super(0, -1, opc_d2f);
    }
}
