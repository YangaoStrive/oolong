package COM.sootNsmoke.scheme;

public class SchemeException extends RuntimeException
{
    SchemeException(String err)
    {
        super(err);
    }
}

