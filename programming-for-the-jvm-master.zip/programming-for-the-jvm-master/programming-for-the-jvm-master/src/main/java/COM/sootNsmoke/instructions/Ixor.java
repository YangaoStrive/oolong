package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Ixor extends NoArgsSequence
{
    public Ixor()
    {
        super(0, -1, opc_ixor);
    }
}
