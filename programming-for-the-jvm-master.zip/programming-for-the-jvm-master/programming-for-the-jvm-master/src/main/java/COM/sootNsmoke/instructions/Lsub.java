package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Lsub extends NoArgsSequence
{
    public Lsub()
    {
        super(0, -2, opc_lsub);
    }
}
