package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Iushr extends NoArgsSequence
{
    public Iushr()
    {
        super(0, -1, opc_iushr);
    }
}
