package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class L2d extends NoArgsSequence
{
    public L2d()
    {
        super(0, 0, opc_l2d);
    }
}
