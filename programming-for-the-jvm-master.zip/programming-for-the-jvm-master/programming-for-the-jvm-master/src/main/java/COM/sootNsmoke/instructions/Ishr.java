package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Ishr extends NoArgsSequence
{
    public Ishr()
    {
        super(0, -1, opc_ishr);
    }
}
