package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class F2d extends NoArgsSequence
{
    public F2d()
    {
        super(0, 1, opc_f2d);
    }
}
