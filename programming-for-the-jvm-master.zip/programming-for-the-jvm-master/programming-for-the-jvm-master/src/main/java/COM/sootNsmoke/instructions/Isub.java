package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Isub extends NoArgsSequence
{
    public Isub()
    {
        super(0, -1, opc_isub);
    }
}
