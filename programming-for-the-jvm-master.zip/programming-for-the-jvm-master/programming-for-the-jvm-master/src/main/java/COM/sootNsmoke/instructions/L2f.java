package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class L2f extends NoArgsSequence
{
    public L2f()
    {
        super(0, -1, opc_l2f);
    }
}
