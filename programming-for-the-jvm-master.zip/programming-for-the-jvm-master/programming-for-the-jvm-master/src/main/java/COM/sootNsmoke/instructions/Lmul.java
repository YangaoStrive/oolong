package COM.sootNsmoke.instructions;
import COM.sootNsmoke.jvm.*;

public class Lmul extends NoArgsSequence
{
    public Lmul()
    {
        super(0, -2, opc_lmul);
    }
}
